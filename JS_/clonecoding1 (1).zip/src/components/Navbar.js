export default function Navbar() {
  return (
    <div className="Navbar">
      <nav>
        <img src="./logo.png" alt="" className="nav--logo" />
      </nav>
    </div>
  );
}
