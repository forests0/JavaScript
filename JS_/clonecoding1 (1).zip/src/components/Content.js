export default function Content() {
  return (
    <section className="content">
      <img src="./photo-grid.png" className="content--photo" />
      <h1 className="content--header">Online Experiences</h1>
      <p className="content--text">
        Join unique interactive activities led by one-of-a-kind hosts—all
        without leaving home.
      </p>
    </section>
  );
}
