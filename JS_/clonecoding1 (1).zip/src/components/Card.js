export default function Card(props) {
  let badgetext;
  if (props.openSpots === 0) {
    badgetext = "SOLD OUT";
  } else if (props.location === "Online") {
    badgetext = "Online";
  }

  return (
    <div className="card">
      {badgetext && <div className="card--badge">{badgetext}</div>}
      <img src={`${props.img}`} className="card--image" />
      <div className="card--stats">
        <img src="./star.png" className="card--star" />
        <span>{props.rating} </span>
        <span className="gray">({props.reviewpoint})·</span>
        <span className="gray">{props.country}</span>
      </div>
      <p className="card--title">{props.title}</p>
      <p className="bold">From ${props.price} / person</p>
    </div>
  );
}
