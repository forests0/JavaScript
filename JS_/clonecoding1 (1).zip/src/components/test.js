//props
<Com name="Seongho" age={4} />;

function Com(props) {
  return (
    <h1>
      Hi, {props.name}, {props.age}
    </h1>
  );
}

const arr1 = [1, 4, 9, 16];
const map1 = arr1.map((x) => x * 2);
